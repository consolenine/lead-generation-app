import requests
import xml.etree.ElementTree as ET

url = 'https://www.99acres.com/99api/v1/getmy99Response/OeAuXClO43hwseaXEQ/uid/'

headers = {
    'cache-control': 'no-cache',
    'Cookie': '99_ab=5; 99_ab=69; GOOGLE_SEARCH_ID=4221971686133405375',
    'postman-token': 'ffabed2e-a1cc-e508-9ac3-a3b8745b7cd1',
}

xml_data = '<?xml version="1.0"?><query><user_name>KUBER.@99</user_name><pswd>Kuber@2024</pswd><start_date>2024-04-02 00:00:00</start_date><end_date>2024-04-03 23:59:59</end_date></query>'

response = requests.post(url, headers=headers, data={'xml': xml_data})

root = ET.fromstring(response.text)

# Initialize an empty dictionary to store key-value pairs
data_dict = {}

# Iterate through each element in the XML
for elem in root.iter():
    # Extract text content if available
    if elem.text and elem.tag != 'Xml':  # Exclude the root 'Xml' tag
        # Use tag name as key and text content as value
        data_dict[elem.tag] = elem.text.strip()

# Print the dictionary
print(data_dict)
