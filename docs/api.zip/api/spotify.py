import requests
import aiohttp
import asyncio
import json
import time
from spotify_auth import getToken
from filter import extract_contacts
from datetime import datetime

class Spotify:
    def __init__(self, userId, token, parent = None) -> None:
        # Initialize object and get access token
        start_url="open.spotiy.com"
        self.token = token
        self.uid = userId
        self.parent = parent
        self.headers = {
            'Content-Type': 'application/json',
            'Authorization': self.token
        }
        # with open("spotify_auth.json", "r") as file:
        #     data = json.load(file)
            
        # self.oheaders = {
        #     'Content-Type': 'application/json',
        #     'Authorization': 'Bearer '+self.token
        # }
    
    def __str__(self) -> str:
        return f"UID: {self.uid} | PARENT: {self.parent}"    

    def updateToken(self, token):
        self.token = token
        self.headers = {
            'Content-Type': 'application/json',
            'Authorization': self.token
        }
    
    async def getUserPlaylists(self, session, max_retries=3, filters=None):
        request_url = f'https://api.spotify.com/v1/users/{self.uid}/playlists'
        print(f"Getting playlists for user {self.uid}")
        
        retry = 0
        items = []
        while retry < max_retries:
            async with session.get(request_url, headers=self.headers) as response:
                if response.status == 200:
                    playlists = await response.json()
                    
                    filtered1 = playlists.get("items", [])
                    # Filter based on keywords
                    if filters is not None and len(filters["tags"]) > 0:
                        filtered1 = list(filter(lambda x: any([f in x["name"].lower() or f in x["description"].lower() for f in filters["tags"]]), playlists.get("items", [])))
                    
                    playlist_basic = list(map(lambda x: {"href": x["href"]}, filtered1))
                    tasks = [self.extractPlaylistInfo(session, p["href"], filters=filters) for p in playlist_basic]
                    contact_data = await asyncio.gather(*tasks)
                    
                    items.extend(contact_data)
                    # next_url = playlists.get("next")
                    # next_items = 0
                    # if next_url is not None:
                    #     token = getToken("https://open.spotify.com")
                    #     self.updateToken(token)
                    # while next_url is not None and next_items < 10:
                    #     print("gothroughuserplaylistpages")
                    #     async with session.get(next_url, headers=self.headers) as next_response:
                    #         if next_response.status == 200:
                    #             playlists = await response.json()
                    
                    #             filtered1 = playlists.get("items", [])
                    #             # Filter based on keywords
                    #             if filters is not None and len(filters["tags"]) > 0:
                    #                 filtered1 = list(filter(lambda x: any([f in x["name"].lower() or f in x["description"].lower() for f in filters["tags"]]), playlists.get("items", [])))
                                
                    #             playlist_basic = list(map(lambda x: {"href": x["href"]}, filtered1))
                    #             tasks = [self.extractPlaylistInfo(session, p["href"], filters=filters) for p in playlist_basic]
                    #             contact_data = await asyncio.gather(*tasks)
                                
                    #             items.extend(contact_data)
                    #             next_url = playlists.get("next")
                    #             next_items += 1
                    #         else:
                    #             next_items += 1
                    #             break
                    break
                elif response.status >= 500:
                    break
                else:
                    retry += 1
                    print(response.status)
                    print("Failed. Retrying")
                    await asyncio.sleep(10)
        return items
            
    
    async def extractPlaylistInfo(self, session, url, max_retries=1, filters=None):
        retry = 0
        details = {
            "user": self.uid,
            "links": {"free": [], "paid": [], "others": []},
            "phone": [],
            "emails": []
        }
        while retry < max_retries:
            async with session.get(url, headers=self.headers) as response:
                if response.status == 200:
                    playlist = await response.json()
                    
                    # Check For Minimum Likes Filter
                    if filters is not None and filters.get("min_likes") is not None:
                        if playlist["followers"]["total"] < int(filters["min_likes"]):
                            return []
                    # Check For Last Updated Filter
                    total_tracks = playlist["tracks"]["total"]
                    last_updated = datetime.strptime(filters["last_updated"], "%Y-%m-%d")
                    
                    if total_tracks is not None and total_tracks > 0:
                        
                        dates = [datetime.strptime(track["added_at"], "%Y-%m-%dT%H:%M:%SZ") for track in playlist["tracks"]["items"]]
                    
                        latest_date = max(dates)
                    
                        if latest_date < last_updated:
                            return []
                        else:
                            details = extract_contacts(playlist["description"])
                            details["user"] = self.uid
                            details["playlist_urls"] = "https://open.spotify.com/playlist/"+url.split("/")[-1]
                            
                        return details
                    else:
                        return []
                                
                elif response.status >= 500:
                    break
                else:
                    retry += 1
                    print(response.status)
                    print("Failed. Retrying")
                    await asyncio.sleep(10)
        
        return []
    
    def getUserFollowers(self, max_retries=3):
        request_url = f'https://spclient.wg.spotify.com/user-profile-view/v3/profile/{self.uid}/followers?market=from_token'
        
        response = None
        retry = 0
        followers = []
        while retry < max_retries:
            response = requests.get(request_url, headers=self.headers)
            
            if response.status_code == 200:
                followers = response.json()
                
                break
            else:
                retry += 1
                time.sleep(10)
        followers["parent"] = self.uid
        return followers
    
    async def getAsyncUserFollowers(self, session, max_retries=3):
        request_url = f'https://spclient.wg.spotify.com/user-profile-view/v3/profile/{self.uid}/followers?market=from_token'
        
        response = None
        retry = 0
        followers = {}
        while retry < max_retries:
            async with session.get(request_url, headers=self.headers) as response:
                
                if response.status == 200:
                    followers = await response.json()
                    
                    break
                else:
                    retry += 1
                    await asyncio.sleep(10)
        followers["parent"] = self.uid
        return followers