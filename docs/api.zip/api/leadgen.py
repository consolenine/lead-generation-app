from spotify_auth import getToken
from utilities import *
from spotify import Spotify
import asyncio
import json
import aiohttp
import csv
from collections import defaultdict

async def process_client_chunk(client_list_chunk, stack, filters=None):
    async with aiohttp.ClientSession() as session:
        tasks = [c.getUserPlaylists(session=session, filters=filters) for c in client_list_chunk]
        data = await asyncio.gather(*tasks)
        
        for d in data:
            for p in d:
                if p != None:
                    stack.append(p)
    print_elapsed_time()
    
    
    
async def process_clients_in_chunks(client_list, stack, chunk_size=100, filters=None):
    mainstack = [{"user": c.uid, "links": {"free": [], "paid": [], "others": []}, "email": [], "phone": [], 'playlist_urls': []} for c in client_list]
    for i in range(0, len(client_list), chunk_size):
        stack = []
        client_list_chunk = client_list[i:i+chunk_size]
        await process_client_chunk(client_list_chunk, stack, filters)
        
        if len(stack) > 0:
            for item in stack:
                mainstack_user = None
                for user in mainstack:
                    try:
                        if user["user"] == item["user"]:
                            mainstack_user = user
                            break
                    except Exception as e:
                        print(item)
                        print(e)
                        break
                print(item)
                lead = False
                if mainstack_user is not None and len(item["links"]["free"]) > 0:
                    mainstack_user["links"]["free"].extend(item["links"]["free"])
                    lead = True
                if mainstack_user is not None and len(item["links"]["paid"]) > 0:    
                    mainstack_user["links"]["paid"].extend(item["links"]["paid"])
                    lead = True
                if mainstack_user is not None and len(item["links"]["others"]) > 0:
                    mainstack_user["links"]["others"].extend(item["links"]["others"])
                    lead = True
                if mainstack_user is not None and len(item["phone"]) > 0:
                    mainstack_user["phone"].extend(item["phone"])
                    lead = True
                if mainstack_user is not None and len(item["email"]) > 0:
                    mainstack_user["email"].extend(item["email"])
                    lead = True
                if lead:
                    mainstack_user["playlist_urls"].append(item["playlist_urls"])
    
    
    for lead1 in mainstack:
        lead_parent1 = lead1["user"]
        lead1["email"] = list(set(lead1["email"]))
        lead1["phone"] = list(set(lead1["phone"]))
        lead1["links"]["free"] = list(set(lead1["links"]["free"]))
        lead1["links"]["paid"] = list(set(lead1["links"]["paid"]))
        lead1["links"]["others"] = list(set(lead1["links"]["others"]))
        
        for lead2 in mainstack:
            lead_parent2 = lead2["user"]
            if lead_parent1 != lead_parent2:
                # Remove duplicate emails across users
                for email in lead2["email"]:
                    if email in lead1["email"]:
                        lead2["email"].remove(email)
                # Remove duplicate phone numbers across users
                for phone in lead2["phone"]:
                    if phone in lead1["phone"]:
                        lead2["phone"].remove(phone)
                # Remove duplicate links across users
                for link in lead2["links"]["free"]:
                    if link in lead1["links"]["free"]:
                        lead2["links"]["free"].remove(link)
                for link in lead2["links"]["paid"]:
                    if link in lead1["links"]["paid"]:
                        lead2["links"]["paid"].remove(link)
                for link in lead2["links"]["others"]:
                    if link in lead1["links"]["others"]:
                        lead2["links"]["others"].remove(link)

                
    final_leads = []    
    
    for l in mainstack:
        if l is not None and (len(l["links"]["free"]) > 0 or len(l["links"]["paid"]) > 0 or len(l["links"]["others"]) > 0 or len(l["phone"]) > 0 or len(l["email"])):
            final_leads.append(l)
    return final_leads

async def leadGenerator(startPoint, filters=None):
    global start_time
    start_time = time.time()
    print_elapsed_time()
    
    with open("playlists.csv", "w") as _:
        writer = csv.writer(_)
        dd = ["artist_id", "playlist_name", "playlist_description"]
        writer.writerow(dd)
    
    stack = []
    
    client_token = getToken("https://open.spotify.com")
    
    print_elapsed_time()
    if client_token is not None:
        
        user_id = startPoint  # Replace with your user ID
        client = Spotify(user_id, client_token)
        
        followers = client.getUserFollowers()
        
        client_list_d1 = [client]
        ii = 1
        if followers is not None and followers.get("profiles") is not None:
            for profile in followers["profiles"]:
                uid = profile["uri"].split(":")[-1]
                client = Spotify(uid, client_token, parent=user_id)
                client_list_d1.append(client)
                print(ii)
                ii += 1
        
        # target_clients = client_list_d1[1:]
        
        # async with aiohttp.ClientSession() as session:
        #     tasks = [client.getAsyncUserFollowers(session=session) for client in target_clients]
        
        #     data = await asyncio.gather(*tasks, return_exceptions=True)
            
        #     for d in data:
        #         if d is not None and d.get("profiles") is not None:
        #             for profile in d["profiles"]:
        #                 uid = profile["uri"].split(":")[-1]
        #                 client = Spotify(uid, client_token, parent=d["parent"])
        #                 client_list_d1.append(client)
        #                 print(ii)
        #                 ii += 1
        
        with open("user_test_data_1.txt", "w") as _:
            for __ in client_list_d1:
                _.write(str(__) +"\n")
        
        leads = await process_clients_in_chunks(client_list_d1, stack, filters=filters)
        print("Collected Data")
        # print("Filtering")
        # leads = filterLeads()  
        return leads
        
            
        
        


if __name__ == "__main__":
    # asyncio.run(leadGenerator("rfy3991wwpjvgh3k1825inhnm"))
    asyncio.run(leadGenerator("magicmusicsquad", filters={
        "min_likes": 1000,
        "last_updated": "2015-01-01",
        "tags": [],
        "lead_type": ["email", "links", "phone"],
        "max_leads": 50
    }))
        