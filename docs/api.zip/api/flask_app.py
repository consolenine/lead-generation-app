from flask import Flask, redirect, request, jsonify, render_template
from spotify_auth import refreshToken, read_config
from leadgen import leadGenerator
from datetime import datetime, timedelta
import random
import string
import urllib.parse
import base64
import requests
import json
import asyncio
import re

app = Flask(__name__)

client_id = '6dba0e90f6744a0398dedd802a56d270'
client_secret = '21f51bd8f0a24708948068e3472b6bdb'
redirect_uri = 'http://localhost:8888/callback'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/admin/spotify-connect')
def spotify_connect():
    
    state = generate_random_string(16)
    scope = 'playlist-read-private playlist-read-collaborative'
    
    o, r, a, x = read_config()
    if o:
        authorization_url = ('/callback?' +
                            urllib.parse.urlencode({
                                'client_id': client_id,
                                'refresh_token': r,
                                'state': state
                            }))

        # Redirect the user to the authorization URL
        return redirect(authorization_url)
    
    # Construct the authorization URL
    authorization_url = ('https://accounts.spotify.com/authorize?' +
                        urllib.parse.urlencode({
                            'response_type': 'code',
                            'client_id': client_id,
                            'scope': scope,
                            'redirect_uri': redirect_uri,
                            'state': state
                        }))

    # Redirect the user to the authorization URL
    return redirect(authorization_url)

@app.route('/callback')
def callback():
    code = request.args.get('code')
    state = request.args.get('state')
    refresh_token = request.args.get('refresh_token', False)

    if state is None:
        return redirect('/#' + urllib.parse.urlencode({'error': 'state_mismatch'}))
    else:
        
        auth_options = None
        
        if refresh_token:
            refresh_token()
            return redirect('/')
        else:
        
            auth_options = {
                'url': 'https://accounts.spotify.com/api/token',
                'data': {
                    'code': code,
                    'redirect_uri': redirect_uri,
                    'grant_type': 'authorization_code'
                },
                'headers': {
                    'content-type': 'application/x-www-form-urlencoded',
                    'Authorization': 'Basic ' + base64.b64encode(f'{client_id}:{client_secret}'.encode()).decode()
                }
            }
        response = requests.post(**auth_options)
        
        # Process the response
        if response.status_code == 200:
            access_token = response.json().get('access_token')
            
            with open('spotify_auth.json', 'w') as file:
                current_time = datetime.now()
                new_time = current_time + timedelta(seconds=int(response.json().get('expires_in', '0')))
                w_data = {
                    "authenticated": True,
                    "refresh_token": response.json().get('refresh_token', refresh_token),
                    "access_token": access_token,
                    "expiry": new_time.strftime('%Y-%m-%d %H:%M:%S')
                }
                file.write(json.dumps(w_data, indent=4))
                
            # Use access_token as needed
            return redirect('/')
        else:
            return jsonify({'error': 'Failed to retrieve access token'}), response.status_code

@app.route('/admin')
def authorize():
    o, r, a, x = read_config()
    return render_template('admin/index.html', authenticated=o)

@app.route('/get_leads')
def leads():
    
    url= request.args.get('username')
    username = re.search(r'/user/([^/]+)', url).group(1) if re.search(r'/user/([^/]+)', url) else url
    tags = request.args.get('tags').split(',')
    if tags[0] == '':
        tags = []
    tags = [tag.strip() for tag in tags]
    
    last_updated = str(request.args.get('date').format('%Y-%m-%d')) or '2015-01-01'
    min_likes = request.args.get('min_likes') or 0
    
    async def main(username):
        result = await leadGenerator(username, filters={
            "min_likes": min_likes,
            "last_updated": last_updated,
            "tags": tags,
            "lead_type": ["email", "links", "phone"],
            "max_leads": 50
        })
        return result
    
    # Create an event loop
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    # Run the async task within the event loop
    result = loop.run_until_complete(main(username))
    
    # Once the result is available, return a response to the client
    response = jsonify(result)
    return response

def generate_random_string(length):
    letters_and_digits = string.ascii_letters + string.digits
    return ''.join(random.choice(letters_and_digits) for i in range(length))

if __name__ == '__main__':
    app.run(port=8888, debug=True)
