import time

global start_time
start_time = time.time()
def print_elapsed_time():
    global start_time
    # elapsed_time = time.time() - start_time
    # print("Time Elapsed: {:.2f} seconds".format(elapsed_time))
    
    # start_time = time.time()
